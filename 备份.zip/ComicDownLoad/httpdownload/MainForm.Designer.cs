﻿namespace comicDownLoad
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.numLabel = new System.Windows.Forms.Label();
            this.comicNavBar = new DevExpress.XtraNavBar.NavBarControl();
            this.manhuadui = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem16 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem17 = new DevExpress.XtraNavBar.NavBarItem();
            this.mangabzName = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem31 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem32 = new DevExpress.XtraNavBar.NavBarItem();
            this.jiu0ManHua = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem29 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem30 = new DevExpress.XtraNavBar.NavBarItem();
            this.huhumanhua = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem25 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem26 = new DevExpress.XtraNavBar.NavBarItem();
            this.hanhanmanhua = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem18 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem19 = new DevExpress.XtraNavBar.NavBarItem();
            this.k886 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem14 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem15 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem1 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem2 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem4 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem5 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem3 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem6 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem7 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem8 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem9 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem10 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem11 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem12 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem13 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem20 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem21 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem22 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem23 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem24 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem27 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem28 = new DevExpress.XtraNavBar.NavBarItem();
            this.jiuLingManHua = new DevExpress.XtraNavBar.NavBarItem();
            this.mainFrame = new DevExpress.XtraBars.Navigation.NavigationFrame();
            this.navigationPage2 = new DevExpress.XtraBars.Navigation.NavigationPage();
            this.resultListView = new comicDownLoad.DoublebufferListview();
            this.Collectcontext = new CCWin.SkinControl.SkinContextMenuStrip();
            this.reamoveCollect = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.navigationPage1 = new DevExpress.XtraBars.Navigation.NavigationPage();
            this.downContext = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.downnLoadTool = new System.Windows.Forms.ToolStripMenuItem();
            this.fullChoiceTool = new System.Windows.Forms.ToolStripMenuItem();
            this.unChoiceTool = new System.Windows.Forms.ToolStripMenuItem();
            this.checkPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addFavrourate = new CCWin.SkinControl.SkinButton();
            this.startReadBtn = new CCWin.SkinControl.SkinButton();
            this.label1 = new System.Windows.Forms.Label();
            this.authorLab = new System.Windows.Forms.LinkLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.descLable = new System.Windows.Forms.Label();
            this.tagLabe = new System.Windows.Forms.Label();
            this.statusLab = new System.Windows.Forms.Label();
            this.comicNameLabel = new System.Windows.Forms.Label();
            this.comicPicBox = new DevExpress.XtraEditors.PictureEdit();
            this.navigationPage3 = new DevExpress.XtraBars.Navigation.NavigationPage();
            this.searchListView = new comicDownLoad.DoublebufferListview();
            this.resultLabel = new System.Windows.Forms.Label();
            this.manhuaduiCheck = new System.Windows.Forms.RadioButton();
            this.hanhanCheck = new System.Windows.Forms.RadioButton();
            this.downBtn = new CCWin.SkinControl.SkinButton();
            this.homeBtn = new CCWin.SkinControl.SkinButton();
            this.lastPageBtn = new CCWin.SkinControl.SkinButton();
            this.lastBtn = new CCWin.SkinControl.SkinButton();
            this.runGif = new CCWin.SkinControl.GifBox();
            this.readerBtn = new CCWin.SkinControl.SkinButton();
            this.collectBtn = new CCWin.SkinControl.SkinButton();
            this.jiulingCheck = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.searchControl = new CCWin.SkinControl.SkinTextBox();
            this.searchBtn = new CCWin.SkinControl.SkinButton();
            ((System.ComponentModel.ISupportInitialize)(this.comicNavBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainFrame)).BeginInit();
            this.mainFrame.SuspendLayout();
            this.navigationPage2.SuspendLayout();
            this.Collectcontext.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabControl1)).BeginInit();
            this.navigationPage1.SuspendLayout();
            this.downContext.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comicPicBox.Properties)).BeginInit();
            this.navigationPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // progressBar1
            // 
            this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.progressBar1.Location = new System.Drawing.Point(307, 623);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(81, 16);
            this.progressBar1.TabIndex = 12;
            // 
            // numLabel
            // 
            this.numLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numLabel.AutoSize = true;
            this.numLabel.Font = new System.Drawing.Font("宋体", 12F);
            this.numLabel.Location = new System.Drawing.Point(560, 621);
            this.numLabel.Name = "numLabel";
            this.numLabel.Size = new System.Drawing.Size(0, 16);
            this.numLabel.TabIndex = 14;
            // 
            // comicNavBar
            // 
            this.comicNavBar.ActiveGroup = this.manhuadui;
            this.comicNavBar.BackColor = System.Drawing.Color.Transparent;
            this.comicNavBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.comicNavBar.Groups.AddRange(new DevExpress.XtraNavBar.NavBarGroup[] {
            this.mangabzName,
            this.manhuadui,
            this.jiu0ManHua,
            this.huhumanhua,
            this.hanhanmanhua,
            this.k886});
            this.comicNavBar.Items.AddRange(new DevExpress.XtraNavBar.NavBarItem[] {
            this.navBarItem1,
            this.navBarItem2,
            this.navBarItem4,
            this.navBarItem5,
            this.navBarItem3,
            this.navBarItem6,
            this.navBarItem7,
            this.navBarItem8,
            this.navBarItem9,
            this.navBarItem10,
            this.navBarItem11,
            this.navBarItem12,
            this.navBarItem13,
            this.navBarItem14,
            this.navBarItem15,
            this.navBarItem16,
            this.navBarItem17,
            this.navBarItem18,
            this.navBarItem19,
            this.navBarItem20,
            this.navBarItem21,
            this.navBarItem22,
            this.navBarItem23,
            this.navBarItem24,
            this.navBarItem25,
            this.navBarItem26,
            this.navBarItem27,
            this.navBarItem28,
            this.jiuLingManHua,
            this.navBarItem29,
            this.navBarItem30,
            this.navBarItem31,
            this.navBarItem32});
            this.comicNavBar.Location = new System.Drawing.Point(0, 0);
            this.comicNavBar.Name = "comicNavBar";
            this.comicNavBar.OptionsNavPane.ExpandedWidth = 237;
            this.comicNavBar.Size = new System.Drawing.Size(237, 662);
            this.comicNavBar.TabIndex = 30;
            this.comicNavBar.Text = "navBarControl1";
            this.comicNavBar.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.comicNavBar_LinkClicked);
            // 
            // manhuadui
            // 
            this.manhuadui.Caption = "漫画堆";
            this.manhuadui.Expanded = true;
            this.manhuadui.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem16),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem17)});
            this.manhuadui.Name = "manhuadui";
            // 
            // navBarItem16
            // 
            this.navBarItem16.Caption = "热门";
            this.navBarItem16.Name = "navBarItem16";
            // 
            // navBarItem17
            // 
            this.navBarItem17.Caption = "分类";
            this.navBarItem17.Name = "navBarItem17";
            // 
            // mangabzName
            // 
            this.mangabzName.Caption = "mangabz";
            this.mangabzName.Expanded = true;
            this.mangabzName.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem31),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem32)});
            this.mangabzName.Name = "mangabzName";
            // 
            // navBarItem31
            // 
            this.navBarItem31.Caption = "热门";
            this.navBarItem31.Name = "navBarItem31";
            // 
            // navBarItem32
            // 
            this.navBarItem32.Caption = "分类";
            this.navBarItem32.Name = "navBarItem32";
            // 
            // jiu0ManHua
            // 
            this.jiu0ManHua.Caption = "90漫画";
            this.jiu0ManHua.Expanded = true;
            this.jiu0ManHua.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem29),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem30)});
            this.jiu0ManHua.Name = "jiu0ManHua";
            // 
            // navBarItem29
            // 
            this.navBarItem29.Caption = "热门";
            this.navBarItem29.Name = "navBarItem29";
            // 
            // navBarItem30
            // 
            this.navBarItem30.Caption = "分类";
            this.navBarItem30.Name = "navBarItem30";
            // 
            // huhumanhua
            // 
            this.huhumanhua.Caption = "虎虎漫画";
            this.huhumanhua.Expanded = true;
            this.huhumanhua.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem25),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem26)});
            this.huhumanhua.Name = "huhumanhua";
            // 
            // navBarItem25
            // 
            this.navBarItem25.Caption = "热门";
            this.navBarItem25.Name = "navBarItem25";
            // 
            // navBarItem26
            // 
            this.navBarItem26.Caption = "分类";
            this.navBarItem26.Name = "navBarItem26";
            // 
            // hanhanmanhua
            // 
            this.hanhanmanhua.Caption = "";
            this.hanhanmanhua.Expanded = true;
            this.hanhanmanhua.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem18),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem19)});
            this.hanhanmanhua.Name = "hanhanmanhua";
            this.hanhanmanhua.SmallImage = global::comicDownLoad.Properties.Resources.hanhan;
            // 
            // navBarItem18
            // 
            this.navBarItem18.Caption = "热门";
            this.navBarItem18.Name = "navBarItem18";
            // 
            // navBarItem19
            // 
            this.navBarItem19.Caption = "分类";
            this.navBarItem19.Name = "navBarItem19";
            // 
            // k886
            // 
            this.k886.Caption = "";
            this.k886.Expanded = true;
            this.k886.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem14),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem15)});
            this.k886.Name = "k886";
            this.k886.SmallImage = ((System.Drawing.Image)(resources.GetObject("k886.SmallImage")));
            // 
            // navBarItem14
            // 
            this.navBarItem14.Caption = "热门";
            this.navBarItem14.Name = "navBarItem14";
            // 
            // navBarItem15
            // 
            this.navBarItem15.Caption = "分类";
            this.navBarItem15.Name = "navBarItem15";
            // 
            // navBarItem1
            // 
            this.navBarItem1.Caption = "热门";
            this.navBarItem1.Name = "navBarItem1";
            // 
            // navBarItem2
            // 
            this.navBarItem2.Caption = "分类";
            this.navBarItem2.Name = "navBarItem2";
            // 
            // navBarItem4
            // 
            this.navBarItem4.Caption = "热门";
            this.navBarItem4.Name = "navBarItem4";
            // 
            // navBarItem5
            // 
            this.navBarItem5.Caption = "分类";
            this.navBarItem5.Name = "navBarItem5";
            // 
            // navBarItem3
            // 
            this.navBarItem3.Caption = "推荐";
            this.navBarItem3.Name = "navBarItem3";
            // 
            // navBarItem6
            // 
            this.navBarItem6.Caption = "navBarItem6";
            this.navBarItem6.Name = "navBarItem6";
            // 
            // navBarItem7
            // 
            this.navBarItem7.Caption = "热门";
            this.navBarItem7.Name = "navBarItem7";
            // 
            // navBarItem8
            // 
            this.navBarItem8.Caption = "分类";
            this.navBarItem8.Name = "navBarItem8";
            // 
            // navBarItem9
            // 
            this.navBarItem9.Caption = "推荐";
            this.navBarItem9.Name = "navBarItem9";
            // 
            // navBarItem10
            // 
            this.navBarItem10.Caption = "热门";
            this.navBarItem10.Name = "navBarItem10";
            // 
            // navBarItem11
            // 
            this.navBarItem11.Caption = "分类";
            this.navBarItem11.Name = "navBarItem11";
            // 
            // navBarItem12
            // 
            this.navBarItem12.Caption = "热门";
            this.navBarItem12.Name = "navBarItem12";
            // 
            // navBarItem13
            // 
            this.navBarItem13.Caption = "分类";
            this.navBarItem13.Name = "navBarItem13";
            // 
            // navBarItem20
            // 
            this.navBarItem20.Caption = "热门";
            this.navBarItem20.Name = "navBarItem20";
            // 
            // navBarItem21
            // 
            this.navBarItem21.Caption = "分类";
            this.navBarItem21.Name = "navBarItem21";
            // 
            // navBarItem22
            // 
            this.navBarItem22.Caption = "热门";
            this.navBarItem22.Name = "navBarItem22";
            // 
            // navBarItem23
            // 
            this.navBarItem23.Caption = "分类";
            this.navBarItem23.Name = "navBarItem23";
            // 
            // navBarItem24
            // 
            this.navBarItem24.Caption = "navBarItem24";
            this.navBarItem24.Name = "navBarItem24";
            // 
            // navBarItem27
            // 
            this.navBarItem27.Caption = "热门";
            this.navBarItem27.Name = "navBarItem27";
            // 
            // navBarItem28
            // 
            this.navBarItem28.Caption = "分类";
            this.navBarItem28.Name = "navBarItem28";
            // 
            // jiuLingManHua
            // 
            this.jiuLingManHua.Caption = "90漫画";
            this.jiuLingManHua.Name = "jiuLingManHua";
            // 
            // mainFrame
            // 
            this.mainFrame.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mainFrame.Controls.Add(this.navigationPage2);
            this.mainFrame.Controls.Add(this.navigationPage1);
            this.mainFrame.Controls.Add(this.navigationPage3);
            this.mainFrame.Location = new System.Drawing.Point(255, 33);
            this.mainFrame.Name = "mainFrame";
            this.mainFrame.Pages.AddRange(new DevExpress.XtraBars.Navigation.NavigationPageBase[] {
            this.navigationPage2,
            this.navigationPage1,
            this.navigationPage3});
            this.mainFrame.SelectedPage = this.navigationPage2;
            this.mainFrame.Size = new System.Drawing.Size(1059, 567);
            this.mainFrame.TabIndex = 31;
            this.mainFrame.Text = "navigationFrame1";
            this.mainFrame.TransitionAnimationProperties.FrameInterval = 1000;
            // 
            // navigationPage2
            // 
            this.navigationPage2.Caption = "navigationPage2";
            this.navigationPage2.Controls.Add(this.resultListView);
            this.navigationPage2.Controls.Add(this.tabControl1);
            this.navigationPage2.Name = "navigationPage2";
            this.navigationPage2.Size = new System.Drawing.Size(1059, 567);
            // 
            // resultListView
            // 
            this.resultListView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.resultListView.ContextMenuStrip = this.Collectcontext;
            this.resultListView.Location = new System.Drawing.Point(0, 39);
            this.resultListView.Name = "resultListView";
            this.resultListView.Size = new System.Drawing.Size(1059, 525);
            this.resultListView.TabIndex = 22;
            this.resultListView.UseCompatibleStateImageBehavior = false;
            this.resultListView.DoubleClick += new System.EventHandler(this.resultListView_DoubleClick);
            // 
            // Collectcontext
            // 
            this.Collectcontext.Arrow = System.Drawing.Color.Black;
            this.Collectcontext.Back = System.Drawing.Color.White;
            this.Collectcontext.BackRadius = 4;
            this.Collectcontext.Base = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(200)))), ((int)(((byte)(254)))));
            this.Collectcontext.DropDownImageSeparator = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.Collectcontext.Fore = System.Drawing.Color.Black;
            this.Collectcontext.HoverFore = System.Drawing.Color.White;
            this.Collectcontext.ItemAnamorphosis = true;
            this.Collectcontext.ItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.Collectcontext.ItemBorderShow = true;
            this.Collectcontext.ItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.Collectcontext.ItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.Collectcontext.ItemRadius = 4;
            this.Collectcontext.ItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.Collectcontext.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reamoveCollect});
            this.Collectcontext.ItemSplitter = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.Collectcontext.Name = "Collectcontext";
            this.Collectcontext.RadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.Collectcontext.Size = new System.Drawing.Size(125, 26);
            this.Collectcontext.SkinAllColor = true;
            this.Collectcontext.TitleAnamorphosis = true;
            this.Collectcontext.TitleColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(228)))), ((int)(((byte)(236)))));
            this.Collectcontext.TitleRadius = 4;
            this.Collectcontext.TitleRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // reamoveCollect
            // 
            this.reamoveCollect.Name = "reamoveCollect";
            this.reamoveCollect.Size = new System.Drawing.Size(124, 22);
            this.reamoveCollect.Text = "移除收藏";
            this.reamoveCollect.Click += new System.EventHandler(this.reamoveCollect_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Location = new System.Drawing.Point(3, 7);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Size = new System.Drawing.Size(1059, 33);
            this.tabControl1.TabIndex = 21;
            this.tabControl1.TabPageWidth = 50;
            this.tabControl1.SelectedPageChanged += new DevExpress.XtraTab.TabPageChangedEventHandler(this.tabControl1_SelectedPageChanged);
            // 
            // navigationPage1
            // 
            this.navigationPage1.Caption = "navigationPage1";
            this.navigationPage1.ContextMenuStrip = this.downContext;
            this.navigationPage1.Controls.Add(this.checkPanel);
            this.navigationPage1.Controls.Add(this.addFavrourate);
            this.navigationPage1.Controls.Add(this.startReadBtn);
            this.navigationPage1.Controls.Add(this.label1);
            this.navigationPage1.Controls.Add(this.authorLab);
            this.navigationPage1.Controls.Add(this.panel2);
            this.navigationPage1.Controls.Add(this.tagLabe);
            this.navigationPage1.Controls.Add(this.statusLab);
            this.navigationPage1.Controls.Add(this.comicNameLabel);
            this.navigationPage1.Controls.Add(this.comicPicBox);
            this.navigationPage1.Name = "navigationPage1";
            this.navigationPage1.Size = new System.Drawing.Size(1059, 567);
            // 
            // downContext
            // 
            this.downContext.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.downnLoadTool,
            this.fullChoiceTool,
            this.unChoiceTool});
            this.downContext.Name = "downContext";
            this.downContext.Size = new System.Drawing.Size(101, 70);
            // 
            // downnLoadTool
            // 
            this.downnLoadTool.Name = "downnLoadTool";
            this.downnLoadTool.Size = new System.Drawing.Size(100, 22);
            this.downnLoadTool.Text = "下载";
            this.downnLoadTool.Click += new System.EventHandler(this.downnLoadTool_Click);
            // 
            // fullChoiceTool
            // 
            this.fullChoiceTool.Name = "fullChoiceTool";
            this.fullChoiceTool.Size = new System.Drawing.Size(100, 22);
            this.fullChoiceTool.Text = "全选";
            this.fullChoiceTool.Click += new System.EventHandler(this.fullChoiceTool_Click);
            // 
            // unChoiceTool
            // 
            this.unChoiceTool.Name = "unChoiceTool";
            this.unChoiceTool.Size = new System.Drawing.Size(100, 22);
            this.unChoiceTool.Text = "反选";
            this.unChoiceTool.Click += new System.EventHandler(this.unChoiceTool_Click);
            // 
            // checkPanel
            // 
            this.checkPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.checkPanel.AutoScroll = true;
            this.checkPanel.Font = new System.Drawing.Font("宋体", 10F);
            this.checkPanel.Location = new System.Drawing.Point(3, 309);
            this.checkPanel.Margin = new System.Windows.Forms.Padding(5);
            this.checkPanel.Name = "checkPanel";
            this.checkPanel.Padding = new System.Windows.Forms.Padding(3);
            this.checkPanel.Size = new System.Drawing.Size(1053, 246);
            this.checkPanel.TabIndex = 15;
            // 
            // addFavrourate
            // 
            this.addFavrourate.BackColor = System.Drawing.Color.Transparent;
            this.addFavrourate.BaseColor = System.Drawing.Color.OrangeRed;
            this.addFavrourate.BorderColor = System.Drawing.Color.OrangeRed;
            this.addFavrourate.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.addFavrourate.DownBack = global::comicDownLoad.Properties.Resources.addHover;
            this.addFavrourate.DownBaseColor = System.Drawing.Color.OrangeRed;
            this.addFavrourate.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.addFavrourate.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addFavrourate.ForeColor = System.Drawing.Color.White;
            this.addFavrourate.GlowColor = System.Drawing.SystemColors.WindowText;
            this.addFavrourate.Location = new System.Drawing.Point(175, 223);
            this.addFavrourate.MouseBack = global::comicDownLoad.Properties.Resources.addMove;
            this.addFavrourate.Name = "addFavrourate";
            this.addFavrourate.NormlBack = global::comicDownLoad.Properties.Resources.addHover;
            this.addFavrourate.Size = new System.Drawing.Size(40, 40);
            this.addFavrourate.TabIndex = 14;
            this.addFavrourate.UseVisualStyleBackColor = false;
            this.addFavrourate.Click += new System.EventHandler(this.addFavrourate_Click);
            // 
            // startReadBtn
            // 
            this.startReadBtn.BackColor = System.Drawing.Color.Transparent;
            this.startReadBtn.BaseColor = System.Drawing.Color.OrangeRed;
            this.startReadBtn.BorderColor = System.Drawing.Color.OrangeRed;
            this.startReadBtn.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.startReadBtn.DownBack = global::comicDownLoad.Properties.Resources.readNormal;
            this.startReadBtn.DownBaseColor = System.Drawing.Color.OrangeRed;
            this.startReadBtn.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.startReadBtn.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.startReadBtn.ForeColor = System.Drawing.Color.White;
            this.startReadBtn.GlowColor = System.Drawing.SystemColors.WindowText;
            this.startReadBtn.Location = new System.Drawing.Point(19, 226);
            this.startReadBtn.MouseBack = global::comicDownLoad.Properties.Resources.readLeave;
            this.startReadBtn.Name = "startReadBtn";
            this.startReadBtn.NormlBack = global::comicDownLoad.Properties.Resources.readNormal;
            this.startReadBtn.Size = new System.Drawing.Size(35, 35);
            this.startReadBtn.TabIndex = 13;
            this.startReadBtn.UseVisualStyleBackColor = false;
            this.startReadBtn.Click += new System.EventHandler(this.startReadBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(231, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 21);
            this.label1.TabIndex = 12;
            this.label1.Text = "作者：";
            // 
            // authorLab
            // 
            this.authorLab.AutoSize = true;
            this.authorLab.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.authorLab.Location = new System.Drawing.Point(295, 43);
            this.authorLab.Name = "authorLab";
            this.authorLab.Size = new System.Drawing.Size(74, 21);
            this.authorLab.TabIndex = 11;
            this.authorLab.TabStop = true;
            this.authorLab.Text = "作者名：";
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.descLable);
            this.panel2.Location = new System.Drawing.Point(230, 144);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(820, 147);
            this.panel2.TabIndex = 10;
            // 
            // descLable
            // 
            this.descLable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.descLable.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.descLable.Location = new System.Drawing.Point(0, 0);
            this.descLable.Name = "descLable";
            this.descLable.Size = new System.Drawing.Size(820, 147);
            this.descLable.TabIndex = 6;
            this.descLable.Text = "简介：";
            // 
            // tagLabe
            // 
            this.tagLabe.AutoSize = true;
            this.tagLabe.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tagLabe.Location = new System.Drawing.Point(231, 78);
            this.tagLabe.Name = "tagLabe";
            this.tagLabe.Size = new System.Drawing.Size(58, 21);
            this.tagLabe.TabIndex = 9;
            this.tagLabe.Text = "标签：";
            // 
            // statusLab
            // 
            this.statusLab.AutoSize = true;
            this.statusLab.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.statusLab.Location = new System.Drawing.Point(231, 110);
            this.statusLab.Name = "statusLab";
            this.statusLab.Size = new System.Drawing.Size(90, 21);
            this.statusLab.TabIndex = 8;
            this.statusLab.Text = "连载状态：";
            // 
            // comicNameLabel
            // 
            this.comicNameLabel.AutoSize = true;
            this.comicNameLabel.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.comicNameLabel.Location = new System.Drawing.Point(231, 7);
            this.comicNameLabel.Name = "comicNameLabel";
            this.comicNameLabel.Size = new System.Drawing.Size(74, 21);
            this.comicNameLabel.TabIndex = 7;
            this.comicNameLabel.Text = "漫画名：";
            // 
            // comicPicBox
            // 
            this.comicPicBox.Cursor = System.Windows.Forms.Cursors.Default;
            this.comicPicBox.Location = new System.Drawing.Point(19, 10);
            this.comicPicBox.Name = "comicPicBox";
            this.comicPicBox.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.comicPicBox.Properties.ZoomAccelerationFactor = 1D;
            this.comicPicBox.Size = new System.Drawing.Size(196, 210);
            this.comicPicBox.TabIndex = 0;
            // 
            // navigationPage3
            // 
            this.navigationPage3.Caption = "navigationPage3";
            this.navigationPage3.Controls.Add(this.searchListView);
            this.navigationPage3.Controls.Add(this.resultLabel);
            this.navigationPage3.Name = "navigationPage3";
            this.navigationPage3.Size = new System.Drawing.Size(1059, 567);
            // 
            // searchListView
            // 
            this.searchListView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.searchListView.Location = new System.Drawing.Point(3, 30);
            this.searchListView.Name = "searchListView";
            this.searchListView.Size = new System.Drawing.Size(1056, 503);
            this.searchListView.TabIndex = 0;
            this.searchListView.UseCompatibleStateImageBehavior = false;
            this.searchListView.DoubleClick += new System.EventHandler(this.searchListView_DoubleClick);
            // 
            // resultLabel
            // 
            this.resultLabel.AutoSize = true;
            this.resultLabel.Location = new System.Drawing.Point(3, 15);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(53, 12);
            this.resultLabel.TabIndex = 36;
            this.resultLabel.Text = "结果数：";
            // 
            // manhuaduiCheck
            // 
            this.manhuaduiCheck.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.manhuaduiCheck.AutoSize = true;
            this.manhuaduiCheck.Location = new System.Drawing.Point(875, 9);
            this.manhuaduiCheck.Name = "manhuaduiCheck";
            this.manhuaduiCheck.Size = new System.Drawing.Size(59, 16);
            this.manhuaduiCheck.TabIndex = 43;
            this.manhuaduiCheck.Text = "漫画堆";
            this.manhuaduiCheck.UseVisualStyleBackColor = true;
            this.manhuaduiCheck.CheckedChanged += new System.EventHandler(this.manhuaduiCheck_CheckedChanged);
            // 
            // hanhanCheck
            // 
            this.hanhanCheck.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.hanhanCheck.AutoSize = true;
            this.hanhanCheck.Checked = true;
            this.hanhanCheck.Location = new System.Drawing.Point(795, 9);
            this.hanhanCheck.Name = "hanhanCheck";
            this.hanhanCheck.Size = new System.Drawing.Size(71, 16);
            this.hanhanCheck.TabIndex = 41;
            this.hanhanCheck.TabStop = true;
            this.hanhanCheck.Text = "汗汗漫画";
            this.hanhanCheck.UseVisualStyleBackColor = true;
            // 
            // downBtn
            // 
            this.downBtn.BackColor = System.Drawing.Color.Transparent;
            this.downBtn.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.downBtn.DownBack = global::comicDownLoad.Properties.Resources.download1;
            this.downBtn.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.downBtn.Location = new System.Drawing.Point(405, 1);
            this.downBtn.MouseBack = global::comicDownLoad.Properties.Resources.downloadLeave;
            this.downBtn.Name = "downBtn";
            this.downBtn.NormlBack = global::comicDownLoad.Properties.Resources.download1;
            this.downBtn.Size = new System.Drawing.Size(32, 32);
            this.downBtn.TabIndex = 40;
            this.downBtn.UseVisualStyleBackColor = false;
            this.downBtn.Click += new System.EventHandler(this.DownComic);
            // 
            // homeBtn
            // 
            this.homeBtn.BackColor = System.Drawing.Color.Transparent;
            this.homeBtn.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.homeBtn.DownBack = global::comicDownLoad.Properties.Resources.qw_homepageNormal;
            this.homeBtn.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.homeBtn.Location = new System.Drawing.Point(307, 1);
            this.homeBtn.MouseBack = global::comicDownLoad.Properties.Resources.qw_homepage;
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.NormlBack = global::comicDownLoad.Properties.Resources.qw_homepageNormal;
            this.homeBtn.Size = new System.Drawing.Size(32, 32);
            this.homeBtn.TabIndex = 0;
            this.homeBtn.UseVisualStyleBackColor = false;
            this.homeBtn.Click += new System.EventHandler(this.homeBtn_Click);
            // 
            // lastPageBtn
            // 
            this.lastPageBtn.BackColor = System.Drawing.Color.Transparent;
            this.lastPageBtn.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.lastPageBtn.DownBack = global::comicDownLoad.Properties.Resources.rightNormal;
            this.lastPageBtn.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.lastPageBtn.Location = new System.Drawing.Point(356, 1);
            this.lastPageBtn.MouseBack = global::comicDownLoad.Properties.Resources.rightHover;
            this.lastPageBtn.Name = "lastPageBtn";
            this.lastPageBtn.NormlBack = global::comicDownLoad.Properties.Resources.rightNormal;
            this.lastPageBtn.Size = new System.Drawing.Size(32, 32);
            this.lastPageBtn.TabIndex = 45;
            this.lastPageBtn.UseVisualStyleBackColor = false;
            this.lastPageBtn.Click += new System.EventHandler(this.lastPageBtn_Click);
            // 
            // lastBtn
            // 
            this.lastBtn.BackColor = System.Drawing.Color.Transparent;
            this.lastBtn.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.lastBtn.DownBack = global::comicDownLoad.Properties.Resources.leftNormal;
            this.lastBtn.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.lastBtn.Location = new System.Drawing.Point(258, 1);
            this.lastBtn.MouseBack = global::comicDownLoad.Properties.Resources.leftHover;
            this.lastBtn.Name = "lastBtn";
            this.lastBtn.NormlBack = global::comicDownLoad.Properties.Resources.leftNormal;
            this.lastBtn.Size = new System.Drawing.Size(32, 32);
            this.lastBtn.TabIndex = 46;
            this.lastBtn.UseVisualStyleBackColor = false;
            this.lastBtn.Click += new System.EventHandler(this.skinButton1_Click);
            // 
            // runGif
            // 
            this.runGif.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.runGif.BorderColor = System.Drawing.Color.Transparent;
            this.runGif.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.runGif.Image = global::comicDownLoad.Properties.Resources.loading;
            this.runGif.Location = new System.Drawing.Point(254, 613);
            this.runGif.Name = "runGif";
            this.runGif.Size = new System.Drawing.Size(47, 37);
            this.runGif.TabIndex = 48;
            this.runGif.Visible = false;
            // 
            // readerBtn
            // 
            this.readerBtn.BackColor = System.Drawing.Color.Transparent;
            this.readerBtn.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.readerBtn.DownBack = global::comicDownLoad.Properties.Resources.readNormal;
            this.readerBtn.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.readerBtn.Location = new System.Drawing.Point(454, 1);
            this.readerBtn.MouseBack = global::comicDownLoad.Properties.Resources.readLeave;
            this.readerBtn.Name = "readerBtn";
            this.readerBtn.NormlBack = global::comicDownLoad.Properties.Resources.readNormal;
            this.readerBtn.Size = new System.Drawing.Size(32, 32);
            this.readerBtn.TabIndex = 49;
            this.readerBtn.UseVisualStyleBackColor = false;
            this.readerBtn.Click += new System.EventHandler(this.readerBtn_Click);
            // 
            // collectBtn
            // 
            this.collectBtn.BackColor = System.Drawing.Color.Transparent;
            this.collectBtn.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.collectBtn.DownBack = global::comicDownLoad.Properties.Resources.星星;
            this.collectBtn.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.collectBtn.Location = new System.Drawing.Point(503, 1);
            this.collectBtn.MouseBack = global::comicDownLoad.Properties.Resources.starleave;
            this.collectBtn.Name = "collectBtn";
            this.collectBtn.NormlBack = global::comicDownLoad.Properties.Resources.星星;
            this.collectBtn.Size = new System.Drawing.Size(32, 32);
            this.collectBtn.TabIndex = 50;
            this.collectBtn.UseVisualStyleBackColor = false;
            this.collectBtn.Click += new System.EventHandler(this.collectBtn_Click);
            // 
            // jiulingCheck
            // 
            this.jiulingCheck.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jiulingCheck.AutoSize = true;
            this.jiulingCheck.Location = new System.Drawing.Point(940, 9);
            this.jiulingCheck.Name = "jiulingCheck";
            this.jiulingCheck.Size = new System.Drawing.Size(59, 16);
            this.jiulingCheck.TabIndex = 53;
            this.jiulingCheck.TabStop = true;
            this.jiulingCheck.Text = "90漫画";
            this.jiulingCheck.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.Location = new System.Drawing.Point(405, 620);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 54;
            this.button1.Text = "暴力测试";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // searchControl
            // 
            this.searchControl.BackColor = System.Drawing.Color.Transparent;
            this.searchControl.DownBack = null;
            this.searchControl.Icon = null;
            this.searchControl.IconIsButton = false;
            this.searchControl.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.searchControl.IsPasswordChat = '\0';
            this.searchControl.IsSystemPasswordChar = false;
            this.searchControl.Lines = new string[0];
            this.searchControl.Location = new System.Drawing.Point(1030, 5);
            this.searchControl.Margin = new System.Windows.Forms.Padding(0);
            this.searchControl.MaxLength = 32767;
            this.searchControl.MinimumSize = new System.Drawing.Size(28, 28);
            this.searchControl.MouseBack = null;
            this.searchControl.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.searchControl.Multiline = false;
            this.searchControl.Name = "searchControl";
            this.searchControl.NormlBack = null;
            this.searchControl.Padding = new System.Windows.Forms.Padding(5);
            this.searchControl.ReadOnly = false;
            this.searchControl.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.searchControl.Size = new System.Drawing.Size(180, 28);
            // 
            // 
            // 
            this.searchControl.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.searchControl.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.searchControl.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.searchControl.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.searchControl.SkinTxt.Name = "BaseText";
            this.searchControl.SkinTxt.Size = new System.Drawing.Size(170, 18);
            this.searchControl.SkinTxt.TabIndex = 0;
            this.searchControl.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.searchControl.SkinTxt.WaterText = "输入漫画名字进行搜索";
            this.searchControl.TabIndex = 55;
            this.searchControl.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.searchControl.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.searchControl.WaterText = "输入漫画名字进行搜索";
            this.searchControl.WordWrap = true;
            // 
            // searchBtn
            // 
            this.searchBtn.BackColor = System.Drawing.Color.Transparent;
            this.searchBtn.BaseColor = System.Drawing.Color.White;
            this.searchBtn.BorderColor = System.Drawing.Color.Silver;
            this.searchBtn.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.searchBtn.DownBack = null;
            this.searchBtn.Location = new System.Drawing.Point(1216, 6);
            this.searchBtn.MouseBack = null;
            this.searchBtn.MouseBaseColor = System.Drawing.Color.Silver;
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.NormlBack = null;
            this.searchBtn.Size = new System.Drawing.Size(75, 23);
            this.searchBtn.TabIndex = 56;
            this.searchBtn.Text = "搜索";
            this.searchBtn.UseVisualStyleBackColor = false;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1317, 662);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.searchControl);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.jiulingCheck);
            this.Controls.Add(this.collectBtn);
            this.Controls.Add(this.readerBtn);
            this.Controls.Add(this.runGif);
            this.Controls.Add(this.manhuaduiCheck);
            this.Controls.Add(this.lastBtn);
            this.Controls.Add(this.hanhanCheck);
            this.Controls.Add(this.lastPageBtn);
            this.Controls.Add(this.homeBtn);
            this.Controls.Add(this.downBtn);
            this.Controls.Add(this.mainFrame);
            this.Controls.Add(this.comicNavBar);
            this.Controls.Add(this.numLabel);
            this.Controls.Add(this.progressBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "漫画下载器";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.comicNavBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainFrame)).EndInit();
            this.mainFrame.ResumeLayout(false);
            this.navigationPage2.ResumeLayout(false);
            this.Collectcontext.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabControl1)).EndInit();
            this.navigationPage1.ResumeLayout(false);
            this.navigationPage1.PerformLayout();
            this.downContext.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.comicPicBox.Properties)).EndInit();
            this.navigationPage3.ResumeLayout(false);
            this.navigationPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label numLabel;
        private DevExpress.XtraNavBar.NavBarControl comicNavBar;
        private DevExpress.XtraNavBar.NavBarItem navBarItem1;
        private DevExpress.XtraNavBar.NavBarItem navBarItem2;
        private DevExpress.XtraNavBar.NavBarItem navBarItem4;
        private DevExpress.XtraNavBar.NavBarItem navBarItem5;
        private DevExpress.XtraBars.Navigation.NavigationFrame mainFrame;
        private DevExpress.XtraBars.Navigation.NavigationPage navigationPage2;
        private DevExpress.XtraTab.XtraTabControl tabControl1;
        private DevExpress.XtraBars.Navigation.NavigationPage navigationPage1;
        private DevExpress.XtraEditors.PictureEdit comicPicBox;
        private DoublebufferListview resultListView;
        private System.Windows.Forms.Label comicNameLabel;
        private System.Windows.Forms.Label tagLabe;
        private System.Windows.Forms.Label statusLab;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label descLable;
        private System.Windows.Forms.LinkLabel authorLab;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip downContext;
        private System.Windows.Forms.ToolStripMenuItem downnLoadTool;
        private System.Windows.Forms.ToolStripMenuItem fullChoiceTool;
        private System.Windows.Forms.ToolStripMenuItem unChoiceTool;
        private DevExpress.XtraNavBar.NavBarItem navBarItem3;
        private DevExpress.XtraNavBar.NavBarItem navBarItem7;
        private DevExpress.XtraNavBar.NavBarItem navBarItem8;
        private DevExpress.XtraNavBar.NavBarItem navBarItem6;
        private DevExpress.XtraNavBar.NavBarItem navBarItem9;
        private DevExpress.XtraBars.Navigation.NavigationPage navigationPage3;
        private DoublebufferListview searchListView;
        private System.Windows.Forms.Label resultLabel;
        private DevExpress.XtraNavBar.NavBarItem navBarItem10;
        private DevExpress.XtraNavBar.NavBarItem navBarItem11;
        private CCWin.SkinControl.SkinButton downBtn;
        private DevExpress.XtraNavBar.NavBarItem navBarItem12;
        private DevExpress.XtraNavBar.NavBarItem navBarItem13;
        private System.Windows.Forms.RadioButton manhuaduiCheck;
        private System.Windows.Forms.RadioButton hanhanCheck;
        private DevExpress.XtraNavBar.NavBarGroup k886;
        private DevExpress.XtraNavBar.NavBarItem navBarItem14;
        private DevExpress.XtraNavBar.NavBarItem navBarItem15;
        private CCWin.SkinControl.SkinButton homeBtn;
        private CCWin.SkinControl.SkinButton lastPageBtn;
        private CCWin.SkinControl.SkinButton lastBtn;
        private CCWin.SkinControl.SkinButton startReadBtn;
        private CCWin.SkinControl.SkinButton addFavrourate;
        private CCWin.SkinControl.GifBox runGif;
        private CCWin.SkinControl.SkinButton readerBtn;
        private DevExpress.XtraNavBar.NavBarGroup manhuadui;
        private DevExpress.XtraNavBar.NavBarItem navBarItem16;
        private DevExpress.XtraNavBar.NavBarItem navBarItem17;
        private CCWin.SkinControl.SkinButton collectBtn;
        private CCWin.SkinControl.SkinContextMenuStrip Collectcontext;
        private System.Windows.Forms.ToolStripMenuItem reamoveCollect;
        private DevExpress.XtraNavBar.NavBarGroup hanhanmanhua;
        private DevExpress.XtraNavBar.NavBarItem navBarItem18;
        private DevExpress.XtraNavBar.NavBarItem navBarItem19;
        private DevExpress.XtraNavBar.NavBarItem navBarItem20;
        private DevExpress.XtraNavBar.NavBarItem navBarItem21;
        private DevExpress.XtraNavBar.NavBarItem navBarItem22;
        private DevExpress.XtraNavBar.NavBarItem navBarItem23;
        private DevExpress.XtraNavBar.NavBarGroup huhumanhua;
        private DevExpress.XtraNavBar.NavBarItem navBarItem25;
        private DevExpress.XtraNavBar.NavBarItem navBarItem26;
        private DevExpress.XtraNavBar.NavBarItem navBarItem24;
        private DevExpress.XtraNavBar.NavBarItem navBarItem27;
        private DevExpress.XtraNavBar.NavBarItem navBarItem28;
        private DevExpress.XtraNavBar.NavBarItem jiuLingManHua;
        private DevExpress.XtraNavBar.NavBarGroup jiu0ManHua;
        private DevExpress.XtraNavBar.NavBarItem navBarItem29;
        private DevExpress.XtraNavBar.NavBarItem navBarItem30;
        private System.Windows.Forms.RadioButton jiulingCheck;
        private DevExpress.XtraNavBar.NavBarGroup mangabzName;
        private DevExpress.XtraNavBar.NavBarItem navBarItem31;
        private DevExpress.XtraNavBar.NavBarItem navBarItem32;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.FlowLayoutPanel checkPanel;
        private CCWin.SkinControl.SkinTextBox searchControl;
        private CCWin.SkinControl.SkinButton searchBtn;
    }
}

